 function calcularIMC()
  {
    var peso, altura, IMC, leyenda;

    peso = document.getElementById("peso").value;
    altura=document.getElementById("altura").value/100;

    IMC = peso/(altura*altura);

    document.getElementById("IMC").value=IMC.toFixed(2);

   
    if(IMC<=20.5){
      leyenda="Estas delgado. Engorda" + (altura* altura * 20.5 -peso).toFixed(1) + " Kilos ";  
      
    }
    else if(IMC=>25.5)
    {
      leyenda="Tienes sobrepeso. Ya bajale" + (peso-altura* altura * 25.5).toFixed(1) + " Kilos ";    
    }
    else 
    {
      leyenda="Estas bien";    
    }
    document.getElementById("observaciones").value=leyenda;
  }
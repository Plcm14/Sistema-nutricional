<?php

class ProgresoData{
	public static $tablename = "progreso";

	public function ProgresoData(){
		$this->peso="";
		$this->altura="";
		$this->talla="";
		$this->IMC="";
		$this->pacient_id="";

		
	}

	public function add(){
		$sql = "insert into progreso (peso, altura, talla, IMC, pacient_id)";
		echo $sql .= "value (\"$this->peso\", \"$this->altura\", \"$this->talla\", \"$this->IMC\", \"$this->pacient_id\")";
		return Executor::doit($sql);
	}

	public static function getAll(){
		$sql = "select * from ".self::$tablename;
		$query = Executor::doit($sql);
		return Model::many($query[0],new ProgresoData());
	}

	public static function getById($id){
		$sql = "select * from ".self::$tablename." where id=$id";
		$query = Executor::doit($sql);
		return Model::one($query[0],new ProgresoData());
	}

	public function update(){
		$sql = "update ".self::$tablename." set peso=\"$this->peso\",altura=\"$this->altura\", talla=\"$this->talla\", IMC=\"$this->IMC\" where id=$this->id";
		Executor::doit($sql);
	}



}




?>
<?php

class ConsultaData{
	public static $tablename = "consulta";

	public function ConsultaData(){
		$this->observaciones="";
		$this->dieta_id="";
		
	}

	public function add(){
		$sql = "insert into consulta (observaciones, dieta_id)";
		echo $sql .= "value (\"$this->observaciones\", \"$this->dieta_id\")";
		return Executor::doit($sql);
	}


	public static function getAll(){
		$sql = "select * from ".self::$tablename;
		$query = Executor::doit($sql);
		return Model::many($query[0],new consultaData());
	}


	public function update(){
		$sql = "update ".self::$tablename." set observaciones=\"$this->observaciones\",dieta_id=\"$this->dieta_id\" where id=$this->id";
		Executor::doit($sql);
	}


	public static function getById($id){
		$sql = "select * from ".self::$tablename." where id=$id";
		$query = Executor::doit($sql);
		return Model::one($query[0],new ConsultaData());
	}
}




?>
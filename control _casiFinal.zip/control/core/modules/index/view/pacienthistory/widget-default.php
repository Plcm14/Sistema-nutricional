	<?php
$pacient = PacientData::getById($_GET["id"]);
$progreso = ProgresoData::getById($_GET["id"]);
$dieta = DietaData::getById($_GET["id"]);
$consulta = ConsultaData::getById($_GET["id"]);
?>

<div class="row">
	<div class="col-md-12">
<div class="btn-group pull-right">
<!--<div class="btn-group pull-right">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
    <i class="fa fa-download"></i> Descargar <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="report/clients-word.php">Word 2007 (.docx)</a></li>
  </ul>
</div>
-->
</div>
		<h1>Historial de Citas del Paciente</h1>
<h4>Paciente: <?php echo $pacient->name." ".$pacient->lastname;?></h4>
<br>
		<?php
		$users = ReservationData::getAllByPacientId($_GET["id"]);
		if(count($users)>0){
			// si hay usuarios
			?>
			<table class="table table-bordered table-hover">
			<thead>
			<th>Medico</th>
			<th>Fecha</th>
			<th>IMC</th>
			<th>Dieta asignada</th>

			</thead>
			<?php
			foreach($users as $user){
				$medic = $user->getMedic();
				$progreso = $user->getProgreso();
				$dieta = $user->getDieta();
				$connsulta = $user->getConsulta();
		
				?>
				<tr>
				<td><?php echo $medic->name." ".$medic->lastname; ?></td>
				<td><?php echo $user->date_at." ".$user->time_at; ?></td>
				<td><?php echo $progreso->IMC. " ".$consulta->observaciones; ?></td>
				<td><?php echo $dieta->nombre; ?></td>

				
				</tr>
				<?php

			}



		}else{
			echo "<p class='alert alert-danger'>No hay citas</p>";
		}


		?>


	</div>
</div>
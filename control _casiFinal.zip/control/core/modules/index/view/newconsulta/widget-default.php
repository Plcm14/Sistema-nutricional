<?php
$pacients = PacientData::getAll();
$medics = MedicData::getAll();
$dieta = DietaData::getAll();

$pacient_id = $_GET["pacient_id"];
$nombre = $_GET["nombre"];
$lastname = $_GET["lastname"];
?>

<script type="application/javascript" src="js/imc.js"></script>

<div class="row">
<div class="col-md-10">
<h1>Consulta</h1>
<h4>Paciente: <?php echo $nombre." ".$lastname ;?></h4>

<form class="form-horizontal" role="form" method="post" action="index.php?view=addconsulta">
  
  <div class='panel-body'>
    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="col-sm-3 control-label">Peso</label>

      <div class="col-sm-9">
        <div class="input-group col-sm-12">
          <input class="string optional form-control" type="text" name="peso" id="peso"/>
          <span class='input-group-addon'>kg</span>
        </div>
      </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="string optional col-sm-3 control-label">Talla</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="string optional form-control" type="text" name="talla" id="talla"/>
            <span class='input-group-addon'>cm</span>
          </div>
        </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="string optional col-sm-3 control-label">Altura</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="form-control" type="text" name="altura" id="altura"/>
            <span class='input-group-addon'>cm</span>
          </div>
        </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group string optional">
        <label class="string optional col-sm-3 control-label">IMC</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="string optional form-control" type="text" value="" name="IMC" id="IMC" onClick="calcularIMC()"/>
            <span class='input-group-addon'>IMC</span>
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label for="inputEmail1" class="col-lg-2 control-label">Observaciones</label>
      
      <div class="col-lg-10">
        <textarea class="form-control" name="observaciones" id="observaciones" placeholder="Observación"></textarea>
      </div>
    </div>

    <div class="form-group">
      <label for="inputEmail1" class="col-lg-2 control-label">Dieta</label>
      
      <div class="col-lg-10">
        <select name="dieta_id" class="form-control">
        <option value="">-- SELECCIONE --</option>
        
        <?php foreach($dieta as $d):?>
          <option value="<?php echo $d->id; ?>"><?php echo $d->id." - ".$d->nombre?></option>
        <?php endforeach; ?>
        </select>
      </div>
    </div>

  </div>

 

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
        <input type="hidden" name="pacient_id" id="pacient_id" value="<?php echo $pacient_id ?>"/>
      <button type="submit" class="btn btn-default">Guardar</button>
    </div>
  </div>
</form>

</div>
</div>


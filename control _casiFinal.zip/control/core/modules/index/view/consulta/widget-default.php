
	
	<h1>Consultas</h1>
<br>
	
	<?php
	$users= array();
	if((isset($_GET["q"]) && isset($_GET["pacient_id"]) && isset($_GET["medic_id"]) && isset($_GET["date_at"])) && ($_GET["q"]!="" || $_GET["pacient_id"]!="" || $_GET["medic_id"]!="" || $_GET["date_at"]!="") ) {
	$sql = "select * from reservation where ";
	if($_GET["q"]!=""){
		$sql .= " title like '%$_GET[q]%' and note like '%$_GET[q] %' ";
	}

	if($_GET["pacient_id"]!=""){
	if($_GET["q"]!=""){
		$sql .= " and ";
	}
		$sql .= " pacient_id = ".$_GET["pacient_id"];
	}

	if($_GET["medic_id"]!=""){
	if($_GET["q"]!=""||$_GET["pacient_id"]!=""){
		$sql .= " and ";
	}

		$sql .= " medic_id = ".$_GET["medic_id"];
	}



	if($_GET["date_at"]!=""){
	if($_GET["q"]!=""||$_GET["pacient_id"]!="" ||$_GET["medic_id"]!="" ){
		$sql .= " and ";
	}

		$sql .= " date_at = \"".$_GET["date_at"]."\"";
	}

			$users = ReservationData::getBySQL($sql);

	}else{
			$users = ReservationData::getAll();

	}
		if(count($users)>0){
			// si hay usuarios
			?>
			<table class="table table-bordered table-hover">
			<thead>
			<th>Asunto</th>
			<th>Paciente</th>
			<th>Medico</th>
			<th>Fecha</th>
			<th></th>
			</thead>
			
			<?php
			foreach($users as $user){
				$pacient  = $user->getPacient();
				$medic = $user->getMedic();
				$consulta = $user->getConsulta();
				?>
				<tr>
				<td><?php echo $user->title; ?></td>
				<td><?php echo $pacient->name." ".$pacient->lastname; ?></td>
				<td><?php echo $medic->name." ".$medic->lastname; ?></td>
				<td><?php echo $user->date_at." ".$user->time_at; ?></td>
				
				<td style="width:230px;">
					<a href="index.php?view=newconsulta&pacient_id=<?php echo $pacient->id;?>&nombre=<?php echo $pacient->name;?>&lastname=<?php echo $pacient->lastname;?>" class="btn btn-default btn-xs ">Iniciar</a>
					
				</td>
				</tr>
			<?php
			}

		}else{
			echo "<p class='alert alert-danger'>No hay pacientes</p>";
		}


		?>


	</div>
</div>



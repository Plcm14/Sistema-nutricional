<?php
	$consulta = new ConsultaData();
	$consulta->observaciones = $_POST["observaciones"];	
	$consulta->dieta_id =$_POST["dieta_id"];
	
	$consulta->add();
?>


<?php
	$progreso = new ProgresoData();
	$progreso->peso = $_POST["peso"];
	$progreso->altura = $_POST["altura"];
	$progreso->talla = $_POST["talla"];
	$progreso->IMC = $_POST["IMC"];
	$progreso->pacient_id = $_POST["pacient_id"];

	$progreso->add();

	print "<script>window.location='index.php?view=consulta';</script>";
		
?>

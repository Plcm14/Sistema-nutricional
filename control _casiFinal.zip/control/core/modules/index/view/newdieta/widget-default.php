<?php
$alimento = AlimentoData::getAll();
$pacients = PacientData::getAll();
$desayuno = AlimentoData::getByIdDes();
$almuerzo = AlimentoData::getByIdAl();
$comida = AlimentoData::getByIdCom();
$merienda = AlimentoData::getByIdMer();
$cena = AlimentoData::getByIdCena();

?>

<div class="row">
  
  <div class="col-md-10">
  <a href="index.php?view=newalimento" class="btn btn-default pull-right"><i class='fa fa-male'></i> Agregar Alimento</a>
	<h1>Nuevo Dieta</h1>
	<br>
		<form class="form-horizontal" method="post" id="addproduct" action="index.php?view=adddieta" role="form">

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Nombre*</label>
    <div class="col-lg-10">
      <input type="text" name="nombre" class="form-control" id="name" placeholder="Nombre">
    </div>
    </div>

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Descripcion*</label>
    <div class="col-lg-10">
    <textarea class="form-control" name="descripcion" id="descripcion" placeholder="Descripcion"></textarea>
    </div>
    </div>

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Ingesta*</label>
    </div>

    <div class="form-group">
        <label for="inputEmail1" class="col-lg-4 control-label">Desayuno</label>
        <div class="col-lg-4">
            <select name="desayuno" class="form-control" required>
            <option value="">-- SELECCIONE --</option>
            
            <?php foreach($desayuno as $d):?>
                <option value="<?php echo $d->nombre; ?>"><?php echo $d->nombre; ?></option>
            <?php endforeach; ?>
            </select>
        </div>
    </div>

     <div class="form-group">
        <label for="inputEmail1" class="col-lg-4 control-label">Almuerzo</label>
        <div class="col-lg-4">
            <select name="almuerzo" class="form-control" required>
            <option value="">-- SELECCIONE --</option>
            
            <?php foreach($almuerzo as $a):?>
                <option value="<?php echo $a->nombre; ?>"><?php echo $a->nombre; ?></option>
            <?php endforeach; ?>
            </select>
        </div>
    </div>

   <div class="form-group">
        <label for="inputEmail1" class="col-lg-4 control-label">Comida</label>
        <div class="col-lg-4">
            <select name="comida" class="form-control" required>
            <option value="">-- SELECCIONE --</option>
            
            <?php foreach($comida as $co):?>
                <option value="<?php echo $co->nombre; ?>"><?php echo $co->nombre; ?></option>
            <?php endforeach; ?>
            </select>
        </div>
    </div>

     <div class="form-group">
        <label for="inputEmail1" class="col-lg-4 control-label">Merienda</label>
        <div class="col-lg-4">
            <select name="merienda" class="form-control" required>
            <option value="">-- SELECCIONE --</option>
            
            <?php foreach($merienda as $m):?>
                <option value="<?php echo $m->nombre; ?>"><?php echo $m->nombre; ?></option>
            <?php endforeach; ?>
            </select>
        </div>
    </div>


     <div class="form-group">
        <label for="inputEmail1" class="col-lg-4 control-label">Cena</label>
        <div class="col-lg-4">
            <select name="cena" class="form-control" required>
            <option value="">-- SELECCIONE --</option>
            
            <?php foreach($cena as $ce):?>
                <option value="<?php echo $ce->nombre; ?>"><?php echo $ce->nombre; ?></option>
            <?php endforeach; ?>
            </select>
        </div>
    </div>





    <p class="alert alert-info">* Campos obligatorios</p>

    <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-primary">Agregar Dieta</button>
    </div>
    </div>
  </form>
	</div>
</div>
<?php
class AlimentoData {
	public static $tablename = "alimento";
	public function AlimentoData(){
		$this->nombre = "";
		$this->descripcion = "";
		$this->tipo = "";
	}

	public function add(){
		$sql = "insert into ".self::$tablename." (nombre,descripcion,tipo) ";
		$sql .= "value (\"$this->nombre\",\"$this->descripcion\",\"$this->tipo\")";
		Executor::doit($sql);
	}

	public static function getAll(){
		$sql = "select * from ".self::$tablename;
		$query = Executor::doit($sql);
		return Model::many($query[0],new AlimentoData());
	}

	public static function delById($id){
		$sql = "delete from ".self::$tablename." where id=$id";
		Executor::doit($sql);
	}
	public function del(){
		$sql = "delete from ".self::$tablename." where id=$this->id";
		Executor::doit($sql);
	}

	public function update(){
		$sql = "update ".self::$tablename." set nombre=\"$this->nombre\",descripcion=\"$this->descripcion\", tipo=\"$this->tipo\" where id=$this->id";
		Executor::doit($sql);
	}

	public static function getById($id){
		$sql = "select * from ".self::$tablename." where id=$id";
		$query = Executor::doit($sql);
		return Model::one($query[0],new AlimentoData());
	}



}

?>
<?php

$client = DietaData::getById($_GET["id"]);
$client->del();
Core::redir("./index.php?view=dieta");

?>
<?php

if(count($_POST)>0){
	$user = new ReservationData();
	$user->title = $_POST["title"];
	$user->date_at = $_POST["date_at"];
	$user->time_at = $_POST["time_at"];
	$user->note = $_POST["note"];
	$user->add();

print "<script>window.location='index.php?view=reservation';</script>";


}


?>
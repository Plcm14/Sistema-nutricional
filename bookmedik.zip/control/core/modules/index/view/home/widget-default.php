<div class="row">
<div class="col-md-12">
<img src= centro.png>
<br/>
<br/>
<br/>
<p>Bienvenido, este sistema te permitira la administracion de tu Centro Nutricional.</p>
<p>Caracteristicas:</p>
<ul>
	<li>Gestion de Citas</li>
	<li>Gestion de Pacientes</li>
	<li>Historial de Citas por Paciente</li>
	<li>Asignacion de Dietas</li>
</ul>
<p>Proyecto de Desarrollo de Software &copy; 2019</p>
</div>
</div>

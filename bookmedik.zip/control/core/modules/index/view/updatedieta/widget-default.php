<?php

if(count($_POST)>0){
	$user = DietaData::getById($_POST["user_id"]);
	$user->nombre = $_POST["nombre"];
	$user->descripcion = $_POST["descripcion"];
	$user->update();


print "<script>window.location='index.php?view=dieta';</script>";


}


?>
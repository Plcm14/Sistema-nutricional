<?php

	$dieta = new DietaData();
	$dieta->nombre = $_POST["nombre"];
	$dieta->descripcion = $_POST["descripcion"];
	$dieta->add();

print "<script>window.location='index.php?view=dieta';</script>";




?>
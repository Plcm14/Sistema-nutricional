<?php
class DietaData {
	public static $tablename = "dieta";
	public function DietaData(){
		$this->nombre = "";
		$this->descripcion = "";
		$this->desayuno ="";
		$this->almuerzo ="";
		$this->comida ="";
		$this->merienda ="";
		$this->cena ="";
	}

	public function getAlimento(){ return AlimentoData::getById($this->id); }

	public function add(){
		$sql = "insert into ".self::$tablename." (nombre,descripcion, desayuno, almuerzo, comida, merienda, cena) ";
		$sql .= "value (\"$this->nombre\",\"$this->descripcion\", \"$this->desayuno\", \"$this->almuerzo\", \"$this->comida\", \"$this->merienda\",\"$this->cena\" )";
		Executor::doit($sql);
	}

	public static function getAll(){
		$sql = "select * from ".self::$tablename;
		$query = Executor::doit($sql);
		return Model::many($query[0],new DietaData());
	}

	public static function delById($id){
		$sql = "delete from ".self::$tablename." where id=$id";
		Executor::doit($sql);
	}
	public function del(){
		$sql = "delete from ".self::$tablename." where id=$this->id";
		Executor::doit($sql);
	}

	public function update(){
		$sql = "update ".self::$tablename." set nombre=\"$this->nombre\",descripcion=\"$this->descripcion\", desauyno=\"$this->desayuno\", almuerzo=\"$this->almuerzo\", comida=\"$this->comida\", merienda=\"$this->merienda\", cena=\"$this->cena\" where id=$this->id";
		Executor::doit($sql);
	}

	public static function getById($id){
		$sql = "select * from ".self::$tablename." where id=$id";
		$query = Executor::doit($sql);
		return Model::one($query[0],new DietaData());
	}



}

?>
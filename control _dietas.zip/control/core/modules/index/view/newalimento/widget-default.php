<div class="row">
  
  <div class="col-md-10">
  
	<h1>Nuevo Alimento</h1>
	<br>
		<form class="form-horizontal" method="post" id="addproduct" action="index.php?view=addalimento" role="form">

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Nombre*</label>
    <div class="col-lg-10">
      <input type="text" name="nombre" class="form-control" id="name" placeholder="Nombre">
    </div>
    </div>

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Descripcion*</label>
    <div class="col-lg-10">
    <textarea class="form-control" name="descripcion" id="descripcion" placeholder="Descripcion"></textarea>
    </div>
    </div>

     <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Ingesta*</label>
    <div class="col-lg-10">
    <select name="tipo"  id="tipo"class="form-control" required>
    <option value="">-- SELECCIONE --</option>
    <option value="Desayuno">Desayuno</option>
    <option value="Almuerzo">Almuerzo</option>
    <option value="Comida">Comida</option>
    <option value="Merienda">Merienda</option>
    <option value="Cena">Cena</option>
    </select>
    </div>
    </div>

    


    <p class="alert alert-info">* Campos obligatorios</p>

    <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-primary">Agregar Dieta</button>
    </div>
    </div>
  </form>
	</div>
</div>
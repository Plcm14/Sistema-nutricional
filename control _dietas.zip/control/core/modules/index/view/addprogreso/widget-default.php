	<?php
	$progreso = new ProgresoData();
	$progreso->peso = $_POST["peso"];
	$progreso->altura = $_POST["altura"];
	$progreso->talla = $_POST["talla"];
	$progreso->IMC = $_POST["IMC"];

	$progreso->add();

	?>

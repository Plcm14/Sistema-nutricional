<?php

	$dieta = new DietaData();
	$dieta->nombre = $_POST["nombre"];
	$dieta->descripcion = $_POST["descripcion"];
	$dieta->desayuno = $_POST["desayuno"];
	$dieta->almuerzo = $_POST["almuerzo"];
	$dieta->comida = $_POST["comida"];
	$dieta->merienda = $_POST["merienda"];
	$dieta->cena = $_POST["cena"];
	$dieta->add();

print "<script>window.location='index.php?view=dieta';</script>";




?>
<?php

	$alimento = new AlimentoData();
	$alimento->nombre = $_POST["nombre"];
	$alimento->descripcion = $_POST["descripcion"];
	$alimento->tipo = $_POST["tipo"];
	$alimento->add();

print "<script>window.location='index.php?view=alimento';</script>";




?>
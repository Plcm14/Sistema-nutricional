<?php $user = DietaData::getById($_GET["id"]);?>
<div class="row">
	<div class="col-md-12">
	<h1>Editar Dieta</h1>
	<br>
		<form class="form-horizontal" method="post" id="addproduct" action="index.php?view=updatedieta" role="form">

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Nombre*</label>
    <div class="col-lg-10">
      <input type="text" name="nombre" value="<?php echo $user->nombre;?>" class="form-control" id="name" placeholder="Nombre">
    </div>
    </div>

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Descripcion*</label>
    <div class="col-lg-10">
    <textarea class="form-control"  name="descripcion" id="descripcion" placeholder="Descripcion"><?php echo $user->descripcion;?></textarea>
    </div>
    </div>

    <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Ingesta*</label>
    </div>

    <p class="alert alert-info">* Campos obligatorios</p>

    <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
    <input type="hidden" name="user_id" value="<?php echo $user->id;?>">
      <button type="submit" class="btn btn-primary">Actualizar Dieta</button>
    </div>
    </div>

  </form>
	</div>
</div>
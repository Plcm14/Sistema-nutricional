<div class="row">
	<div class="col-md-12">
	<div class="btn-group pull-right">
<!--<div class="btn-group pull-right">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
    <i class="fa fa-download"></i> Descargar <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="report/clients-word.php">Word 2007 (.docx)</a></li>
  </ul>
</div>
-->
	</div>
<a href="index.php?view=newdieta" class="btn btn-default pull-right"><i class='fa fa-male'></i> Agregar Dieta</a>
		<h1>Dietas</h1>
<br>
<form class="form-horizontal" role="form">

  <div class="form-group">
    <div class="col-lg-2">
		<div class="input-group">
		  <span class="input-group-addon"><i class="fa fa-search"></i></span>
		  <input type="text" name="q" value="<?php if(isset($_GET["q"]) && $_GET["q"]!=""){ echo $_GET["q"]; } ?>" class="form-control" placeholder="Palabra clave">
		</div>
    </div>
   
    <div class="col-lg-2">
    <button class="btn btn-primary btn-block">Buscar</button>
    </div>

  </div>
</form>
<div class="row">
	<div class="col-md-12">
<div class="btn-group pull-right">
	
<!--<div class="btn-group pull-right">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
    <i class="fa fa-download"></i> Descargar <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="report/clients-word.php">Word 2007 (.docx)</a></li>
  </ul>
</div>
-->
</div>
<br>
		<?php

		$dietas = DietaData::getAll();
		if(count($dietas)>0){
			// si hay dietas
			?>

			<table class="table table-bordered table-hover">
			<thead>
			<th>Nombre</th>
			<th>Descripcion</th>
			<th>Menú</th>
			<th></th>
			</thead>
			<?php
			foreach($dietas as $dieta){?>
			
				<tr>
				<td><?php echo $dieta->nombre; ?></td>
				<td><?php echo $dieta->descripcion; ?></td>
				<td><?php echo $dieta->desayuno.", ".$dieta->almuerzo.", ".$dieta->comida.", ",$dieta->merienda.", ". $dieta->cena; ?></td>
				<td style="width:200px;">
				<a href="index.php?view=editdieta&id=<?php echo $dieta->id;?>" class="btn btn-warning btn-xs">Editar</a>
				<a href="index.php?view=deldieta&id=<?php echo $dieta->id;?>" class="btn btn-danger btn-xs">Eliminar</a>
				</td>
				</tr>
				<?php

			}



		}else{
			echo "<p class='alert alert-danger'>No hay dietas</p>";
		}


		?>


	</div>
</div>


	


<?php
$pacients = PacientData::getAll();
$medics = MedicData::getAll();
?>

<div class="row">
<div class="col-md-10">
<h1>Consulta</h1>
<!--<h4>Paciente: <?php echo $pacient->name." ".$pacient->lastname;?></h4>-->

<form class="form-horizontal" role="form" method="post" action="">
  
  <div class='panel-body'>
    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="col-sm-3 control-label">Peso</label>

      <div class="col-sm-9">
        <div class="input-group col-sm-12">
          <input class="string optional form-control" type="text" name="" id=""/>
          <span class='input-group-addon'>Kg</span>
        </div>
      </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="string optional col-sm-3 control-label">Talla</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="string optional form-control" type="text" name="" id=""/>
            <span class='input-group-addon'>cm</span>
          </div>
        </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="string optional col-sm-3 control-label">Altura</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="form-control" type="text" name="" id=""/>
            <span class='input-group-addon'>mts</span>
          </div>
        </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group string optional">
        <label class="string optional col-sm-3 control-label">Calculo</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="string optional form-control" type="text" name="" id="" />
            <span class='input-group-addon'>IMC</span>
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label for="inputEmail1" class="col-lg-2 control-label">Observaciones</label>
      
      <div class="col-lg-10">
        <textarea class="form-control" name="observacion" placeholder="Observación"></textarea>
      </div>
    </div>

    <div class="form-group">
      <label for="inputEmail1" class="col-lg-2 control-label">Dieta</label>
      
      <div class="col-lg-10">
        <select name="medic_id" class="form-control">
        <option value="">-- SELECCIONE --</option>
        
        <?php foreach($medics as $p):?>
          <option value="<?php echo $p->id; ?>"><?php echo $p->id." - ".$p->name." ".$p->lastname; ?></option>
        <?php endforeach; ?>
        </select>
      </div>
    </div>

  </div>

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-default">Guardar</button>
      <button type="submit" class="btn btn-default">Cancelar</button>
    </div>
  </div>
</form>

</div>
</div>
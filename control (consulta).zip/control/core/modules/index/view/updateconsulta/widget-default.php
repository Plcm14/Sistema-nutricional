<?php

	if(count($_POST)>0){
		$consulta = ConsultaData::getById($_POST["id"]);
		$consulta->observaciones = $_POST["observaciones"];
		$consulta->dieta_id = $_POST["dieta_id"];
		$consulta->update();

		print "<script>window.location='index.php?view=consulta';</script>";

	}
?>


<?php

	if(count($_POST)>0){
		$progreso = ProgresoData::getById($_POST["id"]);
		$progreso->peso = $_POST["peso"];
		$progreso->altura = $_POST["altura"];
		$progreso->talla = $_POST["talla"];
		$progreso->IMC = $_POST["IMC"];
		$progreso->update();

	}

?>


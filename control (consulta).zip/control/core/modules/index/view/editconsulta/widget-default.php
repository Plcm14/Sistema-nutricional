<?php

$id_pacient = $_GET["id_pacient"];
$id_consulta = $_GET["id"];
$nombre = $_GET["nombre"];
$lastname = $_GET["lastname"];
?>

<div class="row">
<div class="col-md-10">
<h1>Consulta</h1>
<h4>Paciente: <?php echo $nombre." ".$lastname ;?></h4>

<form class="form-horizontal" role="form" method="post" action="index.php?view=updateconsulta">
  
  <div class='panel-body'>
    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="col-sm-3 control-label">Peso</label>

      <div class="col-sm-9">
        <div class="input-group col-sm-12">
          <input class="string optional form-control" type="text" name="peso" value="<?php echo $progreso->peso; ?> "/>
          <span class='input-group-addon'>Kg</span>
        </div>
      </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="string optional col-sm-3 control-label">Talla</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="string optional form-control" type="text" name="talla" value="<?php echo $progreso->talla; ?>"/>
            <span class='input-group-addon'>cm</span>
          </div>
        </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group">
        <label class="string optional col-sm-3 control-label">Altura</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="form-control" type="text" name="altura" value="<?php echo $p->altura; ?>"/>
            <span class='input-group-addon'>mts</span>
          </div>
        </div>
      </div>
    </div>

    <div class='col-md-6 col-sm-6'>
      <div class="form-group string optional">
        <label class="string optional col-sm-3 control-label">Calculo</label>

        <div class="col-sm-9">
          <div class="input-group col-sm-12">
            <input class="string optional form-control" type="text" name="IMC" value="<?php echo $p->IMC; ?>"/>
            <span class='input-group-addon'>IMC</span>
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label for="inputEmail1" class="col-lg-2 control-label">Observaciones</label>
      
      <div class="col-lg-10">
        <textarea class="form-control" name="observaciones" placeholder="Observación">
        <?php echo $consulta->observaciones; ?> </textarea>
      </div>
    </div>

    <div class="form-group">
      <label for="inputEmail1" class="col-lg-2 control-label">Dieta</label>
      
      <div class="col-lg-10">
        <select name="dieta_id" class="form-control">
        <option value="">-- SELECCIONE --</option>
        
        <?php foreach($medics as $p):?>
          <option value="<?php echo $p->id; ?>"><?php echo $p->id." - ".$p->name." ".$p->lastname; ?></option>
        <?php endforeach; ?>
        </select>
      </div>
    </div>

  </div>

  <input type="hidden" name="pacient_id" value=" <?php echo $id ?>"/>

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
    <input type="hidden" name="id" value="<?php echo $consulta->id; ?>">
    <input type="hidden" name="id" value="<?php echo $progreso->id; ?>">
      <button type="submit" class="btn btn-default">Guardar</button>
      <button type="submit" class="btn btn-default">Cancelar</button>
    </div>
  </div>
</form>

</div>
</div>